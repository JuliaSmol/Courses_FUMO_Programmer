package sample;

import com.sun.deploy.config.Platform;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class Controller {

    @FXML
    public ResourceBundle resources;

    @FXML
    public URL location;

    @FXML
    public TextField input1;

    @FXML
    public TextField input2;

    @FXML
    public TextField input3;

    @FXML
    public Button btn_solve;

    @FXML
    public Button btn_clear;

    @FXML
    public Button btn_exit;

    @FXML
    public TextField output;

    public double xnumber;
    public double anumber;
    public double bnumber;
    public double result;
    public String answer;



    @FXML
  public   void clear_click(ActionEvent event) {

        input1.setText("");
        input2.setText("");
        input3.setText("");
        output.setText("");
        xnumber=0;
        bnumber=0;
        answer=null;
        anumber=0;
    }

    @FXML
  public   void exit_click(ActionEvent event) {

        System.exit(0);
    }

    @FXML
   public void solve_click(ActionEvent event) {

        xnumber=Double.parseDouble(input1.getText());

        anumber=Double.parseDouble(input2.getText());

        bnumber=Double.parseDouble(input3.getText());

        if ((xnumber<7)||(xnumber==7))
        {
            result=(xnumber+4)/(anumber*anumber+bnumber*bnumber);
            answer=String.format("%.10f",result);
            output.setText(answer);

        }
         else if (xnumber>7){
            result=xnumber*Math.pow((anumber+bnumber),2);
            answer=String.format("%.10f",result);
            output.setText(answer);
        }

    }

    @FXML
    public void initialize() {

    }
}
